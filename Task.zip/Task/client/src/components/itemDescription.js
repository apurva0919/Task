import React from 'react'

import axios from 'axios'


class ItemDescription extends React.Component {
    state = {item: [], ItemLikes: 0}
    async itemsData() {
      const response = await axios.get("http://localhost:3002/items/"+ this.props.location.state.ItemID ,{})
        
      this.setState({item: response.data, ItemLikes: response.data[0].ItemLikes})
    console.log(this.state.ItemLikes)

  }

  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
  }
  

componentDidMount(){
        this.itemsData();
        
    }

    onClick(e) {
      var likes = this.state.ItemLikes + 1
      console.log(likes)

         this.setState({ItemLikes: likes},() => {
  
            console.log(this.state.ItemLikes)} )
        
       
    }
    
    
    render(){
        var item = this.state.item.map((item) => {
            return  <div className="row">
                
            <div className="col-sm-6">
            <h1>{item.ItemTitle}</h1>
            <div className="likes"><button className="icon" onClick={this.onClick}><i style={{fontSize:"24px"}} className="fa">&#xf087;</i></button> Likes: {item.ItemLikes}</div>
                <img className="image" src={item.ItemImage}/>
                
            </div>
            <div className="col-sm-5 content">
                 <div>Price: {item.ItemPrice}</div>
                    <div className="description">{item.ItemDescription}</div>
                
            </div>
        </div>
        })
  // 
    return(
        <div className="container-fluid main" >
            {item}>
          
        </div>
    )
}
}
export default ItemDescription;