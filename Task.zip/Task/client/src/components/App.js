import React from 'react';
import ItemDescription from './itemDescription'

import {BrowserRouter, Route} from 'react-router-dom';
import ItemList from './itemList';


const App = () => {
    return (
        <div className= "container-fluid">
           <BrowserRouter>
           
            
             <Route path="/" exact component={ItemList}/>
             <Route path="/itemdescription" exact component={ItemDescription}/>
            
            
        </BrowserRouter> 
            
            </div>
    )
}
export default App;