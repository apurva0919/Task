import './css/style.css'
import React from 'react';
import Items from './items'
import ItemDescription from './itemDescription';
import axios from 'axios';
import { async } from 'q';





class ItemList extends React.Component {
    state = {items: []}
      async itemsData() {
        const response = await axios.get("http://localhost:3002/items/",{})
       // console.log(response.data);
        this.setState({items: response.data})

    }

   

    componentDidMount(){
        this.itemsData();
    }
   
   

    render(){
    return (
        <div className= "container-fluid">
            
            
                <div>
                    
                    <Items items = {this.state.items}/>
                   
                    
            </div>
            </div>
    )
    }
}
export default ItemList;