import './css/style.css'
import React from 'react';

import {Link} from 'react-router-dom';




const Items = (props) => {
    //console.log(props.items)
    const items = props.items.map((item) => {
  
       // console.log(image);
        return     <div className="flex-item" key={item.ItemID}>
            <div className="card" style={{width: "18rem"},{margin: "20px"}}>
        <img src={item.ItemImage} className="recipe-img" alt={item.ItemImage} style={{height: "5rem"}, {width: "100%"}}/>
        <div className="card-body">
            <h5 className="item-title">{item.ItemTitle}</h5>
            <p className="item-price">{item.ItemPrice}</p>
             <Link to={{ pathname: '/itemDescription', state: { ItemID: item.ItemID} }}>View Details</Link>
         </div>
    </div>
    </div>
    })
    return (
        <div className="flex-container">{items}</div>
      
      
    )
}
export default Items;