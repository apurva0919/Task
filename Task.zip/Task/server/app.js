const express = require('express');
const app = express()
const mysql = require('mysql')
const cors = require("cors");

const bodyParser = require('body-parser')


/* const config = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'start@1234',
    database: 'itemsDB',
})

// Display all users
app.get('/items', (request, response) => {
    config.query('SELECT * FROM items', (error, result) => {
        if (error) throw error;
 
        response.send(result);
    });
}); */

app.use(bodyParser.json)
app.use(cors());
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'start@1234',
    database: 'itemsDB',
})

app.get('/items', (req, res) =>{
    console.log("Fetching a item" + req.params.id)
 
  

const query = "SELECT * FROM Items" 
    connection.query(query,(err, rows, fields) =>{
        console.log("Fetching items successfully")
        
        res.json(rows)
    })
})



app.get('/items/:id', (req, res) =>{
    console.log("Fetching a item" + req.params.id)
 
  
const userID = req.params.id
const query = "SELECT * FROM Items where ItemID = ?" 
    connection.query(query,[userID],(err, rows, fields) =>{
        console.log("Fetching items successfully")
        if (err) throw err
        res.json(rows)
    })
})

// Update an existing item




app.get("/", (req, res)=> {
    console.log("Get Request")
    res.send("Hurray getting data")
})
//localhost: 3002
app.listen('3002',() => {
    console.log("Server is running on 3002");
})